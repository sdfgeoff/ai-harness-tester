# Smoke Initial State

This file exists so the smoke harness can prove the initial state was extracted into the working directory.
